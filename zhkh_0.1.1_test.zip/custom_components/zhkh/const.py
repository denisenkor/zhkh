"""Constants for ЖКХ."""
DOMAIN = "zhkh"
CONF_CONNECTOR = "connector"
CONF_USERNAME = "username"
CONF_PASSWORD = "password"
CONF_ACCOUNT_LABEL = "account_label"
DEFAULT_SCAN_INTERVAL = 30
