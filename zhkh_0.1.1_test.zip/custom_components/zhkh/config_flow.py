"""Config flow for ЖКХ."""
from __future__ import annotations

import voluptuous as vol
from homeassistant import config_entries
from homeassistant.core import callback

from .const import (
    DOMAIN, CONF_CONNECTOR, CONF_USERNAME, CONF_PASSWORD, CONF_ACCOUNT_LABEL,
)


class ZhkhConfigFlow(config_entries.ConfigFlow, domain=DOMAIN):
    VERSION = 1

    async def async_step_user(self, user_input=None):
        if user_input is not None:
            label = user_input[CONF_ACCOUNT_LABEL].strip()
            if not label:
                return self.async_show_form(
                    step_id="user", data_schema=self._schema(user_input),
                    errors={"base": "invalid_label"},
                )

            await self.async_set_unique_id(
                f'{user_input[CONF_CONNECTOR]}_{label.casefold()}'
            )
            self._abort_if_unique_id_configured()
            return self.async_create_entry(title=label, data=user_input)

        return self.async_show_form(step_id="user", data_schema=self._schema())

    @staticmethod
    def _schema(defaults=None):
        defaults = defaults or {}
        return vol.Schema({
            vol.Required(CONF_CONNECTOR, default="tce_crimea"): vol.In({
                "tce_crimea": "Крымтеплокоммунэнерго"
            }),
            vol.Required(
                CONF_ACCOUNT_LABEL,
                default=defaults.get(CONF_ACCOUNT_LABEL, "Крымтеплокоммунэнерго"),
            ): str,
            vol.Required(CONF_USERNAME): str,
            vol.Required(CONF_PASSWORD): str,
        })

    @staticmethod
    @callback
    def async_get_options_flow(config_entry):
        return ZhkhOptionsFlow(config_entry)


class ZhkhOptionsFlow(config_entries.OptionsFlow):
    def __init__(self, config_entry):
        self.config_entry = config_entry

    async def async_step_init(self, user_input=None):
        return self.async_abort(reason="not_supported")
