"""TCE Crimea provider connector."""
from __future__ import annotations

from .api import TceCrimeaApi


class TceCrimeaConnector:
    PROVIDER_NAME = 'ГУП РК «Крымтеплокоммунэнерго»'

    def __init__(self, hass, entry):
        self.api = TceCrimeaApi(
            entry.data["username"],
            entry.data["password"],
        )

    async def async_fetch_data(self):
        debt = await self.api.async_get_debt()
        return {
            "provider": self.PROVIDER_NAME,
            "debt": debt,
        }

    async def async_close(self):
        await self.api.async_close()
