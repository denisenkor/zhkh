"""HTTP client for the TCE Crimea personal account."""
from __future__ import annotations

import aiohttp
from bs4 import BeautifulSoup
from yarl import URL


class TceCrimeaApi:
    BASE_URL = "https://lk.tce.crimea.ru"
    LOGIN_URL = f"{BASE_URL}/cabinet/"
    SERVICES_URL = f"{BASE_URL}/services"
    LOGIN_FORM_ID = "user-login-form"

    def __init__(self, username: str, password: str):
        self.username = username
        self.password = password
        self.session: aiohttp.ClientSession | None = None

    async def _get_session(self) -> aiohttp.ClientSession:
        if self.session is None or self.session.closed:
            timeout = aiohttp.ClientTimeout(total=30, connect=10)
            self.session = aiohttp.ClientSession(
                timeout=timeout,
                headers={
                    "User-Agent": "HomeAssistant-Zhkh/0.1.1",
                    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                },
            )
        return self.session

    async def _login(self) -> None:
        session = await self._get_session()

        async with session.get(self.LOGIN_URL, allow_redirects=True) as response:
            response.raise_for_status()
            login_html = await response.text()

        soup = BeautifulSoup(login_html, "html.parser")
        form = soup.find("form", id=self.LOGIN_FORM_ID)
        if form is None:
            # A valid existing session may already have redirected to /services.
            if await self._has_account_page(session):
                return
            raise RuntimeError("Не найдена форма входа на сайте поставщика")

        payload: dict[str, str] = {}
        for field in form.find_all("input"):
            name = field.get("name")
            if not name:
                continue
            field_type = (field.get("type") or "").lower()
            if field_type == "hidden":
                payload[name] = field.get("value", "")
        payload["name"] = self.username
        payload["pass"] = self.password

        submit = form.find("input", attrs={"type": "submit", "name": "op"})
        if submit is not None:
            payload["op"] = submit.get("value", "Войти")
        else:
            payload.setdefault("op", "Войти")

        action = form.get("action") or "/cabinet?destination=cabinet"
        post_url = str(URL(self.BASE_URL).join(URL(action)))

        async with session.post(
            post_url,
            data=payload,
            allow_redirects=True,
            headers={"Referer": self.LOGIN_URL},
        ) as response:
            response.raise_for_status()
            response_html = await response.text()
            final_url = str(response.url)

        # Drupal may redirect after POST; explicitly request the confirmed page
        # using the same cookie jar to make the retrieval deterministic.
        if self.LOGIN_FORM_ID in response_html and "/services" not in final_url:
            raise RuntimeError("Сайт не принял учётные данные или не завершил вход")

        if not await self._has_account_page(session):
            raise RuntimeError("После входа не удалось открыть страницу личного кабинета")

    async def _has_account_page(self, session: aiohttp.ClientSession) -> bool:
        async with session.get(self.SERVICES_URL, allow_redirects=True) as response:
            response.raise_for_status()
            html = await response.text()
            if self.LOGIN_FORM_ID in html:
                return False
            return BeautifulSoup(html, "html.parser").select_one(
                ".info_column_primary"
            ) is not None

    async def async_get_services_html(self) -> str:
        session = await self._get_session()
        async with session.get(self.SERVICES_URL, allow_redirects=True) as response:
            response.raise_for_status()
            html = await response.text()

        soup = BeautifulSoup(html, "html.parser")
        if soup.find("form", id=self.LOGIN_FORM_ID):
            # Session expired: get a fresh form token and authenticate again.
            await self._login()
            async with session.get(self.SERVICES_URL, allow_redirects=True) as response:
                response.raise_for_status()
                html = await response.text()
                soup = BeautifulSoup(html, "html.parser")

        if soup.select_one(".info_column_primary") is None:
            raise RuntimeError("На странице /services не найден блок .info_column_primary")
        return html

    async def async_get_debt(self) -> float:
        html = await self.async_get_services_html()
        return parse_debt(html)

    async def async_close(self) -> None:
        if self.session and not self.session.closed:
            await self.session.close()


def parse_debt(html: str) -> float:
    """Extract balance from the 'Состояние расчетов' value.

    Debt is positive; overpayment is negative; explicit zero/no-debt text is 0.
    """
    soup = BeautifulSoup(html, "html.parser")
    container = soup.select_one(".info_column_primary")
    if container is None:
        raise ValueError("Не найден блок информации о лицевом счёте")

    titles = container.select(".title")
    for title in titles:
        normalized_title = " ".join(title.get_text(" ", strip=True).lower().split()).rstrip(":")
        if normalized_title not in {
            "состояние расчетов", "состояние расчётов"
        }:
            continue

        value_node = title.find_next_sibling(class_="value")
        if value_node is None:
            raise ValueError("Не найдено значение поля «Состояние расчетов»")

        text = " ".join(value_node.get_text(" ", strip=True).lower().split())
        if any(phrase in text for phrase in (
            "задолженность отсутствует", "долга нет", "нет задолженности",
            "переплата отсутствует",
        )):
            return 0.0

        import re
        if re.search(r"(?<!\d)0(?:[.,]0{1,2})?\s*руб", text):
            return 0.0
        match = re.search(
            r"(?P<kind>долг|задолженность|переплата)\D*"
            r"(?P<amount>\d[\d\s\u00a0\u202f]*(?:[.,]\d{1,2})?)\s*руб",
            text,
            flags=re.IGNORECASE,
        )
        if not match:
            # Some account pages show only a numeric amount in this field.
            match = re.search(
                r"(?P<amount>\d[\d\s\u00a0\u202f]*(?:[.,]\d{1,2})?)\s*руб",
                text,
                flags=re.IGNORECASE,
            )
            if not match:
                raise ValueError("Не удалось распознать сумму в поле «Состояние расчетов»")

        amount_text = re.sub(r"[\s\u00a0\u202f]", "", match.group("amount")).replace(",", ".")
        amount = float(amount_text)
        if "kind" in match.groupdict() and match.group("kind") == "переплата":
            amount = -amount
        return amount

    raise ValueError("В HTML не найдено поле «Состояние расчетов»")
