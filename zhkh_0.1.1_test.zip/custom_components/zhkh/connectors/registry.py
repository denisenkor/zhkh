"""Connector registry."""
from .tce_crimea.connector import TceCrimeaConnector

CONNECTORS = {"tce_crimea": TceCrimeaConnector}


def get_connector(name):
    try:
        return CONNECTORS[name]
    except KeyError as err:
        raise ValueError(f"Неизвестный коннектор: {name}") from err
