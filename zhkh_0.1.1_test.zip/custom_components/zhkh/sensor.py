"""Exactly two sensors for each provider connection."""
from __future__ import annotations

from homeassistant.components.sensor import (
    SensorEntity, SensorDeviceClass, SensorStateClass,
)
from homeassistant.helpers.device_registry import DeviceInfo
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from .const import DOMAIN


async def async_setup_entry(hass, entry, async_add_entities):
    coordinator = hass.data[DOMAIN][entry.entry_id]
    async_add_entities([
        ProviderSensor(coordinator, entry),
        DebtSensor(coordinator, entry),
    ])


class ZhkhSensor(CoordinatorEntity, SensorEntity):
    _attr_has_entity_name = True

    def __init__(self, coordinator, entry, key, name):
        super().__init__(coordinator)
        self._key = key
        self._attr_name = name
        self._attr_unique_id = f"{entry.entry_id}_{key}"
        self._attr_device_info = DeviceInfo(
            identifiers={(DOMAIN, entry.entry_id)},
            name=entry.title,
            manufacturer="ЖКХ",
            model="Подключение коммунального поставщика",
        )

    @property
    def native_value(self):
        return self.coordinator.data.get(self._key)


class ProviderSensor(ZhkhSensor):
    def __init__(self, coordinator, entry):
        super().__init__(coordinator, entry, "provider", "Поставщик")


class DebtSensor(ZhkhSensor):
    _attr_native_unit_of_measurement = "RUB"
    _attr_device_class = SensorDeviceClass.MONETARY
    _attr_state_class = SensorStateClass.MEASUREMENT

    def __init__(self, coordinator, entry):
        super().__init__(coordinator, entry, "debt", "Задолженность")
