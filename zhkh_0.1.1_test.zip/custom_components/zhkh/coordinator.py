"""Data update coordinator."""
from __future__ import annotations

from datetime import timedelta
import logging

from homeassistant.helpers.update_coordinator import DataUpdateCoordinator, UpdateFailed

from .const import DOMAIN

_LOGGER = logging.getLogger(__name__)


class ZhkhCoordinator(DataUpdateCoordinator):
    def __init__(self, hass, entry, connector_class):
        self.entry = entry
        self.connector = connector_class(hass, entry)
        super().__init__(
            hass,
            _LOGGER,
            name=f"{DOMAIN}_{entry.entry_id}",
            update_interval=timedelta(minutes=30),
        )

    async def _async_update_data(self):
        try:
            return await self.connector.async_fetch_data()
        except Exception as err:
            # Do not include HTTP request bodies, cookies or credentials in logs.
            _LOGGER.warning("Не удалось обновить данные ЖКХ (%s)", type(err).__name__)
            raise UpdateFailed(
                f"Не удалось получить данные поставщика ({type(err).__name__})"
            ) from err

    async def async_close(self):
        await self.connector.async_close()
